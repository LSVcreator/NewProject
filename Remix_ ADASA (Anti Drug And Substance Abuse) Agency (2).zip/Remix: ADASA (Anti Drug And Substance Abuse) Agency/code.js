onEvent("WELCOME", "click", function( ) {
	setScreen("AppOverview");
});
onEvent("RECOVERY", "click", function( ) {
  setScreen("step1");
});
onEvent("llalalala", "click", function( ) {
  setScreen("Home");
});
onEvent("back", "click", function( ) {
  setScreen("Login");
});
onEvent("HELPLINE", "click", function( ) {
  open("https://www.samhsa.gov/find-help/national-helpline");
});
onEvent("bruhhhhhh", "click", function( ) {
  setScreen("Home");
});
onEvent("yololmao", "click", function( ) {
  setScreen("Home");
});
onEvent("MiniStep4", "click", function( ) {
  setScreen("Freewrite");
});
onEvent("togoback", "click", function( ) {
  setScreen("step1");
});
onEvent("togotonextseps", "click", function( ) {
  setScreen("step2");
});
onEvent("yoloitsme", "click", function( ) {
  setScreen("step1");
});
onEvent("Ministep3", "click", function( ) {
  setScreen("guidedwriting");
});
onEvent("guidedwirtingbutton", "click", function( ) {
  setScreen("step1");
});
onEvent("acceptencedupe", "click", function( ) {
  open("https://youtu.be/E_18V7klRY8");
});
onEvent("MiniStep2", "click", function( ) {
  setScreen("acceptence");
});
onEvent("gobacktostep1", "click", function( ) {
  setScreen("step1");
});
onEvent("tedtalks", "click", function( ) {
  setScreen("tedtalk");
});
onEvent("letsopenlink", "click", function( ) {
  open("https://www.youtube.com/watch?v=1qI-Qn7xass");
});
onEvent("backto3", "click", function( ) {
  setScreen("Minipathway3");
});
onEvent("GOALS", "click", function( ) {
  setScreen("Goals");
});
onEvent("Next2", "click", function( ) {
  setScreen("Goals2");
});
onEvent("button9", "click", function( ) {
  setScreen("SetPersonalGoals");
});
onEvent("Back2Goals", "click", function( ) {
  setScreen("Goals2");
});
onEvent("button2", "click", function( ) {
  setScreen("Goals");
});
onEvent("2.1", "click", function( ) {
  setScreen("2.1screen");
});
onEvent("2.1", "click", function( ) {
  setScreen("2.1screen");
});
onEvent("backtostep2", "click", function( ) {
  setScreen("step2");
});
onEvent("2.2screen", "click", function( ) {
	console.log("2.2screen clicked!");
});
onEvent("2.2", "click", function( ) {
  setScreen("2.2screen");
});
onEvent("gobackto2.2", "click", function( ) {
  setScreen("step2");
});
onEvent("textdupe", "click", function( ) {
  setScreen("AppOverview");
});
onEvent("taytay", "click", function( ) {
  setScreen("Home");
});
onEvent("lmaoitsmehiiiii", "click", function( ) {
  setScreen("Home");
});
onEvent("whatuphomie", "click", function( ) {
  setScreen("Home");
});
onEvent("yellowstone", "click", function( ) {
  setScreen("Home");
});
onEvent("button19", "click", function( ) {
  setScreen("Home");
});
onEvent("button20", "click", function( ) {
  setScreen("Home");
});
onEvent("button21", "click", function( ) {
  setScreen("Home");
});
onEvent("button22", "click", function( ) {
  setScreen("Home");
});
onEvent("radio_button1", "change", function( ) {
	console.log("radio_button1 checked? " + getChecked("radio_button1"));
});
onEvent("radio_button2", "change", function( ) {
	console.log("radio_button2 checked? " + getChecked("radio_button2"));
});
onEvent("radio_button3", "change", function( ) {
	console.log("radio_button3 checked? " + getChecked("radio_button3"));
});
onEvent("heybabes", "click", function( ) {
  setScreen("step2");
});
onEvent("2.3", "click", function( ) {
  setScreen("2.3screen");
});
onEvent("button16", "click", function( ) {
  setScreen("screen1");
});
onEvent("button15", "click", function( ) {
  setScreen("2.3screen");
});
onEvent("button16", "click", function( ) {
  setScreen("correctanswer");
});
onEvent("himynameislola", "click", function( ) {
  setScreen("question2");
});
onEvent("button18", "click", function( ) {
  setScreen("correctanswer");
});
onEvent("button23", "click", function( ) {
  setScreen("correcanswer2");
});
onEvent("button24", "click", function( ) {
  setScreen("step2");
});
onEvent("go2step3", "click", function( ) {
  setScreen("WhatIsStep3?");
});
onEvent("cappybara", "click", function( ) {
  setScreen("WhatIsStep3?");
});
onEvent("Ta", "click", function( ) {
  setScreen("step3");
});
onEvent("BackWIS3", "click", function( ) {
  setScreen("Home");
});
onEvent("Family", "click", function( ) {
  setScreen("FamilySupport");
});
onEvent("tedtalky", "click", function( ) {
  setScreen("tedtalk");
});
onEvent("backbutton", "click", function( ) {
  setScreen("Home");
});
onEvent("button1claim", "click", function( ) {
  setScreen("Claim1");
});
onEvent("backto3", "click", function( ) {
  setScreen("FamilySupport");
});
onEvent("button1p", "click", function( ) {
  setScreen("tedtalk");
});
onEvent("Back2claim1", "click", function( ) {
  setScreen("Claim1");
});
onEvent("button1y", "click", function( ) {
  setScreen("Claim2");
});
onEvent("button2claim3", "click", function( ) {
  setScreen("Claim3");
});
onEvent("button25", "click", function( ) {
  setScreen("Claim2");
});
onEvent("letsGo2step3", "click", function( ) {
  setScreen("Step3");
});
onEvent("Ministep123456", "click", function( ) {
  onEvent("Ashley", "click", function( ) {
    open("https://www.ashleytreatment.org/rehab-blog/step-three-in-alcoholics-anonymous/");
  });
  onEvent("Yellowstone", "click", function( ) {
    open("https://www.yellowstonerecovery.com/2016/12/27/a-deeper-look-at-the-12-steps-step-3/");
  });
  setScreen("ResourcesStep3");
});
onEvent("BackRS3", "click", function( ) {
  setScreen("Step3");
});
onEvent("MiniStep3", "click", function( ) {
  setScreen("GuidedWritingStep3");
});
onEvent("BackGW3", "click", function( ) {
  setScreen("Step3");
});
onEvent("MiniStepyjctjycjyrcjyr", "click", function( ) {
  setScreen("SelfReflectionStep3");
});
onEvent("BackSRS3", "click", function( ) {
  setScreen("Step3");
});
onEvent("Back2step2", "click", function( ) {
  setScreen("step2");
});
onEvent("step4444", "click", function( ) {
  setScreen("Step4");
});
onEvent("IdentifyingStep4", "click", function( ) {
  setScreen("EvaluationStep4");
});
onEvent("BackEvaulation", "click", function( ) {
  setScreen("Step4");
});
onEvent("SetForSuccessStep4", "click", function( ) {
  setScreen("SuccessStep4");
});
onEvent("BackSuccess4", "click", function( ) {
  setScreen("Step4");
});
onEvent("alkdfalkdfj", "click", function( ) {
  setScreen("werwerwerwer");
});
onEvent("adfadmfn,madfn,mdnf", "click", function( ) {
  setScreen("Step3");
});
onEvent("BackMessage", "click", function( ) {
  setScreen("Step4");
});
onEvent("Iffy", "click", function( ) {
  setImageURL("ImageforSucessFor", "ifffffffy-removebg-preview.png");
});
onEvent("decent", "click", function( ) {
  setImageURL("Success", "good-removebg-preview.png");
});
onEvent("VeryGood", "click", function( ) {
  setImageURL("ImageforSucessFor", "download-removebg-preview.png");
});
onEvent("HomeStep4", "click", function( ) {
  setScreen("Home");
});
onEvent("HomefromStories", "click", function( ) {
  setScreen("Home");
});
onEvent("Next2Stories", "click", function( ) {
  setScreen("Stories");
});
onEvent("Bad", "click", function( ) {
  setImageURL("Success", "assets/AngryEmoji.png");
});
onEvent("Sad", "click", function( ) {
  setImageURL("Success", "https://code.org/images/logo.png");
});
onEvent("Sad", "click", function( ) {
  setImageURL("Success", "assets/Sad-Face-Emoji.png");
});
onEvent("EitherWay", "click", function( ) {
  setImageURL("Success", "assets/impartial.png");
});
onEvent("decent", "click", function( ) {
  setImageURL("Success", "image-removebg-preview-(1).png");
});
onEvent("VeryGood", "click", function( ) {
  setImageURL("Success", "assets/image2-removebg-preview.png");
});
onEvent("HonestyLillerStoryBook", "click", function( ) {
  open("https://www.amazon.com/Scattered-Pink-Diary-Woman-Recovery/dp/B09RPH7QJ8");
});
onEvent("HomefromStories", "click", function( ) {
  setScreen("Home");
});
onEvent("adf", "click", function( ) {
  setImageURL("DogRAH", "assets/cake-removebg-preview.png");
});
onEvent("lkjlkj", "click", function( ) {
  setImageURL("CatRAH", "assets/party-removebg-preview.png");
});
onEvent("aldflkajsdflkj", "click", function( ) {
  setImageURL("TurtleRAH", "assets/yeehaw-removebg-preview.png");
});
onEvent("amdnf,amfdnm,", "click", function( ) {
  setImageURL("FishRAH", "assets/present-removebg-preview.png");
});
onEvent("a,dfmnadfn,admfn", "click", function( ) {
  setImageURL("a,dfmnadfn,admfn", "assets/flower_after-removebg-preview.png");
});
onEvent("Dog", "click", function( ) {
  setImageURL("blanknoanimal", "assets/pngtree-cartoon-panda-sleep-png-image_8493140-removebg-preview.png");
});
onEvent("Cat", "click", function( ) {
  setImageURL("blanknoanimal", "assets/anfjkadfjnadfkjfdn-removebg-preview.png");
});
onEvent("Turtle", "click", function( ) {
  setImageURL("blanknoanimal", "assets/ksdajflkajsdflakjfd-removebg-preview.png");
});
onEvent("HOMEFROMOVERVIEW", "click", function( ) {
  setScreen("Login");
});
onEvent("button37", "click", function( ) {
  open("https://www.wakemonarchacademy.org/");
});
onEvent("button35", "click", function( ) {
  setScreen("Home");
});
onEvent("image14", "click", function( ) {
  setImageURL("image14", "assets/image-removebg-preview.png");
});
onEvent("button33", "click", function( ) {
  setScreen("resources");
});
onEvent("welcomespanish", "click", function( ) {
  playSpeech("Welcome to Your Journey", "female", "English");
});
onEvent("SpanishOverview", "click", function( ) {
  playSpeech("ADASA is about not letting drugs control your life. We give it back to you through steps of recovery, personalized goals, and cultivating empathy in an environment that supports your journey. It includes information from interviews conducted with executive directors of rehabilitation centers, resources to guide you to the right path, and constant motivation from us. We believe in you.", "female", "English");
});
onEvent("HomeSpanish", "click", function( ) {
  playSpeech("Back Home Recovery Goals Family Help Line Resources", "female", "English");
});
onEvent("Step1Spanish", "click", function( ) {
  playSpeech("Free Write Guided Writing Acceptance", "female", "English");
});
onEvent("SpanishAcceptance", "click", function( ) {
  playSpeech("Watch this video by Chris Herren speaking about his drug addiction recovery journey", "female", "English");
});
onEvent("SpanishGuidedWritingS1", "click", function( ) {
  playSpeech("What are you excited for in recovery? What are you worried for in recovery? Do you feel ready for this new chapter in your life?", "female", "English");
});
onEvent("SpanishStep2", "click", function( ) {
  playSpeech("Back Quiz Time Talk about your feelings Affirmation Home Next", "female", "English");
});
onEvent("SpanishAffirmation", "click", function( ) {
  playSpeech("Recovery is hard, regret is harder", "female", "English");
});
onEvent("SpanishFeelingSlider", "click", function( ) {
  playSpeech(" How are you feeling today? Drag the slider ", "female", "English");
});
onEvent("SpanishQuizq1", "click", function( ) {
  playSpeech("How many people suffer from drug addiction every year? 37 million people 10 million people 88 thousand people", "female", "English");
});
onEvent("SpanishQuizq2", "click", function( ) {
  playSpeech("How much does substance abuse cost someone in the long run? 1 million 20 thousand 9 hundred", "female", "English");
});
onEvent("SpanishStep3", "click", function( ) {
  playSpeech("Back Self Reflection Guided Writing Helpful Resources Next", "female", "English");
});
onEvent("SpanishResourcesStep3", "click", function( ) {
  playSpeech("Some helpful links for step 3. Ashley recovery- a brief description of step 3 recovery. Yellowstone Recovery- Helpful tips for completing step 3 of recovery Click the button to change the animal. Remember progress isn't always linear ", "female", "English");
});
onEvent("SpanishWritingSTEP3", "click", function( ) {
  playSpeech("Who are some people who can support you? Who makes you feel happy and strong? Is there anything/anyone else who can help you through this journey?", "female", "English");
});
onEvent("SpanishSelfReflectionS3", "click", function( ) {
  playSpeech("How do you think you are doing on your journey so far? Any positives or negatives?", "female", "English");
});
onEvent("SpanishStep4", "click", function( ) {
  playSpeech("Back Creators Message Getting Set for Success Identify your strengths and areas of improvement Home", "female", "English");
});
onEvent("SpanishEvaluation", "click", function( ) {
  playSpeech("What are your strengths? Strengths can be as big or small as you want! Anything you are proud of! What could you improve on? You can always have self improvement and it is never a bad thing!", "female", "English");
});
onEvent("SpanishWIS3", "click", function( ) {
  playSpeech("What is step 3? Step 3 is all about getting help and finding support resources. You can get help from anyone, family or friends! This path will help you find support and many resources and self-lead activities!", "female", "English");
});
onEvent("PlayspeechSuccessStep4", "click", function( ) {
  playSpeech("Do you feel ready for this journey? Select how you are feeling for an image! Angry Sad Impartial Decent Great! What are you most excited for? These feelings are all normmal and valid!", "female", "English");
});
onEvent("PlaySpeechWERWER", "click", function( ) {
  playSpeech("The creators of ADASA would like to congratulate you on how far you've come! We are so proud of you! Recovery is not easy but you are strong and you got this! Click the checkboxes to celebrate your progress!", "female", "English");
});
onEvent("Speech2textfreewrite", "click", function( ) {
  playSpeech("Write whatever you feel", "female", "English");
});
onEvent("GoalsSpeech", "click", function( ) {
  playSpeech("These are goals that get you on the right track. Stay clean for 2 weeks Stay clean for 4 weeks Stay clean for 8 weeks Stay clean for 10 weeks ", "female", "English");
});
onEvent("Goals2Text2Speech", "click", function( ) {
  playSpeech("Stay clean for 12 weeks Stay clean for 14 weeks Stay clean for 18 weeks. Celebrate!", "female", "English");
});
onEvent("SpeechPersonalGoals", "click", function( ) {
  playSpeech("Set Personal goals", "female", "English");
});
onEvent("SpeechFamilySupport", "click", function( ) {
  playSpeech("Support is an important role that families take part in-without it, a child can feel lost. When going down the wrong pathway, they should be there to direct them back to the right one. Otherwise, they should be aware of the situation and assist the addict to their path of recovery every step of the way.  'Addiction is a family disease'   - Leah Wright; executive director of Wake Monarch Academy", "female", "English");
});
onEvent("newlanguage", "click", function( ) {
  setScreen("WelcomeSpanish");
});
onEvent("english", "click", function( ) {
  setScreen("welcome");
});
onEvent("skeyee", "click", function( ) {
  setScreen("screen3");
});
onEvent("atras", "click", function( ) {
  setScreen("Loginspanish");
});
onEvent("button54", "click", function( ) {
  setScreen("Step1spanish");
});
onEvent("backspanish", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button55", "click", function( ) {
  setScreen("Goals1spanish");
});
onEvent("button74", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button72", "click", function( ) {
  setScreen("goals2spanish");
});
onEvent("button76", "click", function( ) {
  setScreen("Goals1spanish");
});
onEvent("button82", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button80", "click", function( ) {
  setScreen("setpersonalgoalspanish");
});
onEvent("button85", "click", function( ) {
  setScreen("goals2spanish");
});
onEvent("button68", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button57", "click", function( ) {
  open("https://www.samhsa.gov/find-help/national-helpline");
});
onEvent("button46", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button56", "click", function( ) {
  setScreen("familyspanish");
});
onEvent("button53", "click", function( ) {
  setScreen("familyspanish");
});
onEvent("button48", "click", function( ) {
  setScreen("tedtalkspanish");
});
onEvent("button52", "click", function( ) {
  open("https://www.youtube.com/watch?v=1qI-Qn7xass");
});
onEvent("button53", "click", function( ) {
  setScreen("familyspanish");
});
onEvent("button58", "click", function( ) {
  setScreen("Globalspanish");
});
onEvent("button62", "click", function( ) {
  setScreen("tedtalkspanish");
});
onEvent("button63", "click", function( ) {
  setScreen("localspanish");
});
onEvent("button67", "click", function( ) {
  setScreen("Globalspanish");
});
onEvent("button83", "click", function( ) {
  setScreen("empathyspanish");
});
onEvent("button87", "click", function( ) {
  setScreen("localspanish");
});
onEvent("button89", "click", function( ) {
  setScreen("storiesspanish");
});
onEvent("button91", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button17", "click", function( ) {
  setScreen("Step1spanish");
});
onEvent("button50", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("freespanish", "click", function( ) {
  setScreen("spanishfreewrite");
});
onEvent("button95", "click", function( ) {
  setScreen("Step1spanish");
});
onEvent("button96", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("guidedspanish", "click", function( ) {
  setScreen("aguidedwritingspanish");
});
onEvent("acceptspanish", "click", function( ) {
  setScreen("acceptencespanishh");
});
onEvent("button99", "click", function( ) {
  setScreen("Step1spanish");
});
onEvent("button100", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("nextspanish", "click", function( ) {
  setScreen("step2spanish");
});
onEvent("button105", "click", function( ) {
  setScreen("Step1spanish");
});
onEvent("button107", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button102", "click", function( ) {
  setScreen("2.3spanish");
});
onEvent("button97", "click", function( ) {
  setScreen("step2spanish");
});
onEvent("button110", "click", function( ) {
  setScreen("2.3spanish");
});
onEvent("button101", "click", function( ) {
  setScreen("correctanswerspanish");
});
onEvent("button116", "click", function( ) {
  setScreen("correctanswerspanish");
});
onEvent("button111", "click", function( ) {
  setScreen("aquestion2spanish");
});
onEvent("button117", "click", function( ) {
  setScreen("correctanswer2spanish");
});
onEvent("button123", "click", function( ) {
  setScreen("step2spanish");
});
onEvent("slider2", "input", function( ) {
	console.log("slider2 value: " + getNumber("slider2"));
});
onEvent("button103", "click", function( ) {
  setScreen("2.2spanish");
});
onEvent("button131", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button130", "click", function( ) {
  setScreen("step2spanish");
});
onEvent("button104", "click", function( ) {
  setScreen("Affrimationspanish");
});
onEvent("button133", "click", function( ) {
  setScreen("step2spanish");
});
onEvent("button134", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button108", "click", function( ) {
  setScreen("step2spanish");
});
onEvent("button107", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button132", "click", function( ) {
  setScreen("Step3spanish");
});
onEvent("button106", "click", function( ) {
  setScreen("whatisstep3spanish");
});
onEvent("button140", "click", function( ) {
  setScreen("whatisstep3spanish");
});
onEvent("button139", "click", function( ) {
  setScreen("step4spanish");
});
onEvent("button145", "click", function( ) {
  setScreen("Step3spanish");
});
onEvent("button146", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button138", "click", function( ) {
  setScreen("step3.1spanish");
});
onEvent("button135", "click", function( ) {
  setScreen("Step3spanish");
});
onEvent("button147", "click", function( ) {
  setScreen("Step3spanish");
});
onEvent("button136", "click", function( ) {
  setScreen("step3.2spanish");
});
onEvent("button150", "click", function( ) {
  setScreen("Step3spanish");
});
onEvent("button160", "click", function( ) {
  setScreen("step4spanish");
});
onEvent("button144", "click", function( ) {
  setScreen("step4.1spanish");
});
onEvent("button163", "click", function( ) {
  setScreen("step4spanish");
});
onEvent("button167", "click", function( ) {
  setScreen("Step3spanish");
});
onEvent("button142", "click", function( ) {
  setScreen("Step4laststep");
});
onEvent("button137", "click", function( ) {
  setScreen("step3.3spanish");
});
onEvent("button143", "click", function( ) {
  setScreen("step4.2spanish");
});
onEvent("button142", "click", function( ) {
  setScreen("Step4laststep");
});
onEvent("TedTalkPlaySPEECH", "click", function( ) {
  playSpeech("Watch this video about how drug addiction is a family disease but know that you can get through it with SUPPORT", "female", "English");
});
onEvent("PlaySpeechClaim1", "click", function( ) {
  playSpeech("Ensuring global access to drug recovery treatments is crucial due to the aggressive marketing of drugs as primary solutions for various health issues, the escalation of teenage depression and anxiety in today's society, and the long-term consequences of drug use persisting into adulthood. Numbers for the manufacturing and seizures of many illicit drugs are hitting record highs' 11.2 million people worldwide were recorded injecting drugs.", "female", "English");
});
onEvent("PlaySpeechClaim2", "click", function( ) {
  playSpeech("With a goal of encouraging teens to refrain from resorting to drugs for artificial happiness, local efforts should include developing better local recovery programs for addicts and supporting organizations like the Wake Monarch Academy that undertake endeavors to accomplish this goal.So what we’re doing is providing them with a safe and supportive environment to continue putting tools in their toolbox of sustaining recovery, but also giving them an education where they can continue their academic studies to achieve a college-ready high school diploma. This gives them an opportunity to heal and not only sustain recovery but work on academics and really learn to be a well-rounded individual.  - Leah Wright", "female", "English");
});
onEvent("PlaySpeechClaim3", "click", function( ) {
  playSpeech("The development of new resources to educate people on the effects of addiction on teens will allow people to improve their relationships, learn how addiction affects others beyond the addict, and avoid misinformation in the media to educate themselves. - shame and embarrassment over a family member’s intoxicated behavior can lead to social isolation and the avoidance of friends or relatives outside the home. These factors can create a destructive cycle in which substance abuse leads to emotional pain or mental instability, which triggers an even greater craving for alcohol or drugs (American Addiction Centers)", "female", "English");
});
onEvent("PlaySpeechStories", "click", function( ) {
  playSpeech("Honesty Liller started using drugs at the age of 12. At 17, she found heroin. Even after she became pregnant, she continued to do let addiction control her life. The program gave her a new chapter to her story and allowed her to make a full recovery. She now works as the full time CEO of McShin. Buy her book to read more about her story. Tyler Lybert was overweight as a child, and started using drugs as a way to fit in with his friends in 6th grade. He was constantly in and out of jail and recovery. His family now talks about how the stress it put on their home environment, changing the lives of everyone in the household. They now work together to communicate their story and spread awareness of the substance abuse crisis. ", "female", "English");
});
onEvent("button98", "click", function( ) {
  open("https://www.youtube.com/watch?v=E_18V7klRY8");
});
onEvent("button151", "click", function( ) {
  open("https://www.ashleytreatment.org/rehab-blog/step-three-in-alcoholics-anonymous/");
});
onEvent("button152", "click", function( ) {
  open("https://www.yellowstonerecovery.com/2016/12/27/a-deeper-look-at-the-12-steps-step-3/");
});
onEvent("radio_button28", "click", function( ) {
  setImageURL("image90", "assets/AngryEmoji.png");
});
onEvent("radio_button29", "click", function( ) {
  setImageURL("image90", "assets/Sad-Face-Emoji.png");
});
onEvent("radio_button30", "click", function( ) {
  setImageURL("image90", "assets/impartial.png");
});
onEvent("radio_button31", "click", function( ) {
  setImageURL("image90", "image-removebg-preview-(1).png");
});
onEvent("radio_button32", "click", function( ) {
  setImageURL("image90", "assets/image2-removebg-preview.png");
});
onEvent("checkbox15", "click", function( ) {
  setImageURL("image86", "assets/cake-removebg-preview.png");
});
onEvent("checkbox16", "click", function( ) {
  setImageURL("image88", "assets/party-removebg-preview.png");
});
onEvent("checkbox17", "click", function( ) {
  setImageURL("image87", "assets/yeehaw-removebg-preview.png");
});
onEvent("checkbox18", "click", function( ) {
  setImageURL("image89", "assets/present-removebg-preview.png");
});
onEvent("image47", "click", function( ) {
  setImageURL("image47", "assets/image-removebg-preview.png");
});
onEvent("image83", "click", function( ) {
  setImageURL("image83", "assets/flower_after-removebg-preview.png");
});
onEvent("radio_button25", "click", function( ) {
  setImageURL("image85", "image-removebg-preview-(4).png");
});
onEvent("radio_button26", "click", function( ) {
  setImageURL("image85", "image-removebg-preview-(5).png");
});
onEvent("radio_button27", "click", function( ) {
  setImageURL("image85", "assets/ksdajflkajsdflakjfd-removebg-preview.png");
});
onEvent("Dog", "click", function( ) {
  setImageURL("image103", "assets/dove-removebg-preview.png");
});
onEvent("Cat", "click", function( ) {
  setImageURL("image103", "assets/hummingbird-removebg-preview.png");
});
onEvent("Turtle", "click", function( ) {
  setImageURL("image103", "assets/better_bees-removebg-preview.png");
});
onEvent("radio_button25", "click", function( ) {
  setImageURL("image85", "assets/dove-removebg-preview.png");
});
onEvent("radio_button26", "click", function( ) {
  setImageURL("image85", "assets/hummingbird-removebg-preview.png");
});
onEvent("radio_button27", "click", function( ) {
  setImageURL("image85", "assets/better_bees-removebg-preview.png");
});
onEvent("button162", "click", function( ) {
  setScreen("AppOverview");
});
onEvent("button166", "click", function( ) {
  setScreen("Home");
});
onEvent("button175", "click", function( ) {
  setScreen("WelcomeSpanish");
});
onEvent("button172", "click", function( ) {
  setScreen("Loginspanish");
});
onEvent("button171", "click", function( ) {
  setScreen("Homespanish");
});
onEvent("button170", "click", function( ) {
  setScreen("screen3");
});
onEvent("button176", "click", function( ) {
  playSpeech("Back     Enter your first name    Enter your last name   Home ", "female", "English");
});
onEvent("button51", "click", function( ) {
  setScreen("welcome");
});
onEvent("2teluguwelcome", "click", function( ) {
  setScreen("TeluguWelcome");
});
onEvent("back2engfromtel", "click", function( ) {
  setScreen("welcome");
});
onEvent("Telugu2welcome", "click", function( ) {
  setScreen("TeluguWelcome");
});
onEvent("Telugu2appoverview", "click", function( ) {
  setScreen("TeluguAppOverview");
});
onEvent("Telugu2login", "click", function( ) {
  setScreen("TeluguLogin");
});
onEvent("Back2Tappoverview", "click", function( ) {
  setScreen("TeluguAppOverview");
});
onEvent("back2telugulogin", "click", function( ) {
  setScreen("TeluguLogin");
});
onEvent("Telugu2Home", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("TeluguRecovery", "click", function( ) {
  setScreen("TeluguStep1");
});
onEvent("Back2homets1", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("TeluguStep1FreeWrite", "click", function( ) {
  setScreen("TeluguFreeWriteStep1");
});
onEvent("Back2step1TE", "click", function( ) {
  setScreen("TeluguStep1");
});
onEvent("HomeTeluguS1.1", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("Back2step1fromguided", "click", function( ) {
  setScreen("TeluguStep1");
});
onEvent("TeluguStep1GuidedWriting", "click", function( ) {
  setScreen("TeluguGuidedWritingS1");
});
onEvent("teluguback2homestep1", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("HomefromTA", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("Back2step1TELUGU", "click", function( ) {
  setScreen("TeluguStep1");
});
onEvent("TeluguAcceptance", "click", function( ) {
  setScreen("TeluguAcceptanceStep1");
});
onEvent("TAvideo", "click", function( ) {
  open("https://www.youtube.com/watch?v=E_18V7klRY8");
});
onEvent("PlaySpeechstep2", "click", function( ) {
  playSpeech("Back Quiz Time Talk about your feelings affirmation home next", "female", "English");
});
onEvent("Back2step1TT", "click", function( ) {
  setScreen("TeluguStep1");
});
onEvent("HomeTT", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("NextStep2", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("TeluguAffirmation", "click", function( ) {
  setScreen("Telugu2.1");
});
onEvent("TH", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("TTB", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("TeluguFeelings2.2", "click", function( ) {
  setScreen("Telugu2.2");
});
onEvent("homett", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("TTS2", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("NextTO2.3.2", "click", function( ) {
  setScreen("TeluguQuiz2.3.2");
});
onEvent("Telugustep2.3.1", "click", function( ) {
  setScreen("TeluguQuiz2.3.1");
});
onEvent("Back2Step2TT", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("backtostep2guys", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("NextTO2.3.3", "click", function( ) {
  setScreen("Telugu2.3.3");
});
onEvent("Backtostep2", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("Next2step2.3.4", "click", function( ) {
  setScreen("Telugu2.3.4");
});
onEvent("back2step2", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("ToHome", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("Go2step2TT", "click", function( ) {
  setScreen("TeluguStep2");
});
onEvent("Go2WIS3TT", "click", function( ) {
  setScreen("TeluguWhatisSTEP3");
});
onEvent("TeluguHelpLine", "click", function( ) {
  open("https://www.samhsa.gov/find-help/national-helpline");
});
onEvent("2step3TT", "click", function( ) {
  setScreen("TeluguStep3");
});
onEvent("button265", "click", function( ) {
  setScreen("TeluguResourcesStep3");
});
onEvent("AshRecovery", "click", function( ) {
  open("https://www.ashleytreatment.org/rehab-blog/step-three-in-alcoholics-anonymous/");
});
onEvent("YellowstoneRecovery", "click", function( ) {
  open("https://www.yellowstonerecovery.com/2016/12/27/a-deeper-look-at-the-12-steps-step-3/");
});
onEvent("back2step3", "click", function( ) {
  setScreen("TeluguStep3");
});
onEvent("button264", "click", function( ) {
  setScreen("TeluguGuidedWritingStep3");
});
onEvent("button270", "click", function( ) {
  setScreen("TeluguStep3");
});
onEvent("button181", "click", function( ) {
  setScreen("TeluguStep3");
});
onEvent("button266", "click", function( ) {
  setScreen("TeluguSelfReflectionStep3");
});
onEvent("button189", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("button188", "click", function( ) {
  setScreen("TeluguStep3");
});
onEvent("button267", "click", function( ) {
  setScreen("TeluguStep4");
});
onEvent("button191", "click", function( ) {
  setScreen("TeluguStep4");
});
onEvent("button185", "click", function( ) {
  setScreen("TeluguStrength&Weak");
});
onEvent("button186", "click", function( ) {
  setScreen("TeluguSuccess");
});
onEvent("button197", "click", function( ) {
  setScreen("TeluguStep4");
});
onEvent("button201", "click", function( ) {
  setScreen("TeluguStep4");
});
onEvent("button187", "click", function( ) {
  setScreen("TeluguCreatorsMessage");
});
onEvent("TeluguGoals", "click", function( ) {
  setScreen("TeluguGoals1");
});
onEvent("button204", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("button210", "click", function( ) {
  setScreen("TeluguGoals2");
});
onEvent("button214", "click", function( ) {
  setScreen("TeluguGoals1");
});
onEvent("button220", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("button218", "click", function( ) {
  setScreen("TeluguSetPersonalGoals");
});
onEvent("button223", "click", function( ) {
  setScreen("TeluguGoals2");
});
onEvent("button224", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("button196", "click", function( ) {
  setScreen("TeluguResourcesCitations");
});
onEvent("TeluguFamily", "click", function( ) {
  setScreen("TeluguFamilySupport");
});
onEvent("button183", "click", function( ) {
  setScreen("TeluguSuccessFamily");
});
onEvent("button200", "click", function( ) {
  setScreen("TeluguFamilySupport");
});
onEvent("button203", "click", function( ) {
  setScreen("TeluguClaim1");
});
onEvent("button194", "click", function( ) {
  open("https://www.youtube.com/watch?v=1qI-Qn7xass");
});
onEvent("button221", "click", function( ) {
  setScreen("TeluguClaim2");
});
onEvent("button240", "click", function( ) {
  setScreen("TeluguClaim1");
});
onEvent("button242", "click", function( ) {
  setScreen("TeluguClaim3");
});
onEvent("button237", "click", function( ) {
  setScreen("TeluguClaim2");
});
onEvent("button213", "click", function( ) {
  setScreen("TeluguSuccessFamily");
});
onEvent("button178", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("button251", "click", function( ) {
  setScreen("Teluguhome");
});
onEvent("button245", "click", function( ) {
  setScreen("TeluguStories");
});
onEvent("button259", "click", function( ) {
  playSound("assets/default.mp3", true);
});
onEvent("guidedwirtingbutton", "click", function( ) {
  setScreen("step1");
});
onEvent("checkbox8", "click", function( ) {
  playSound("assets/category_achievements/lighthearted_bonus_objective_6.mp3", false);
});
onEvent("checkbox8", "click", function( ) {
  setScreen("screen1");
});
